
RVO2 Library

RVO2 Library is an easy-to-use C++ implementation of the Optimal Reciprocal Collision Avoidance
(ORCA) formalism for multi-agent simulation. RVO2 Library automatically uses parallellism for
computing the motion of the agents if your machine has multiple processors and your compiler
supports OpenMP.

Detailed documentation may be found in the doc/ subdirectory.
